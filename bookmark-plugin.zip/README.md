# bookmark-plugin
一个Google浏览器插件，配合[my-bookmart](https://mybookmark.cn)快速添加书签到系统。插件[下载地址](https://chrome.google.com/webstore/detail/%E4%B9%A6%E7%AD%BE%E5%BF%AB%E9%80%9F%E6%B7%BB%E5%8A%A0/lmmobgephofdffmaednjooplcpbgbjle)

![image](https://mybookmark.cn/images/screenshot.gif)  

服务器链接设置：因为有部分人拿我的项目自己部署了一套环境，但是在使用这个插件的时候，数据默认是往服务器 https://mybookmark.cn/ 发送的，为了解决这个问题，将服务器可设置。比如你在你的服务器 http://47.75.89.228:2000/ 部署，那么就填你自己的服务器 http://47.75.89.228:2000/ (注意最后面的 / 必须要填)。这样你使用这个插件的时候，数据就发送到你的服务器上了。每次使用插件添加书签在左上角服务器会显示。

![image](./img/options.png)  
